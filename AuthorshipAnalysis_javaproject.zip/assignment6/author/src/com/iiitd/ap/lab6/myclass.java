/*
 * @author : Kunal Sharma
 * Roll Number : 2014054
 */
package com.iiitd.ap.lab6;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;

public class myclass {
	static Map<String,Integer> abs=new HashMap<String,Integer>();
	static Map<String,Integer> absauthor=new HashMap<String,Integer>();
	static Map<String,Integer> sortedabs=new TreeMap<String,Integer>(Collections.reverseOrder());
	static HashMap<String,Integer> header=new HashMap<String,Integer>();
    static HashMap<String,ArrayList<Integer>> author=new HashMap<String,ArrayList<Integer>>();
	static Map<String,Integer> absoffiles=new HashMap<String,Integer>();
	public static void main(String[] args) {
		int k=0,ter=0,op=0,m=0,z=0;
/////////////////////////////////////////
		int i=1,l=0;
		
		
	    String[] auth;
		while(i<=20)	
		{
			try {

				String s,title,filename;
		         filename="./src/"+"paper"+i+ ".txt";
				@SuppressWarnings("resource")
				BufferedReader name= new BufferedReader(new FileReader(filename));
				
				while ((s = name.readLine())!= null) {
					title=s;
					ArrayList<Integer> count = new ArrayList<Integer>();
					header.put(title,i);
					s = name.readLine();
					s = name.readLine();
					auth=s.split(", ");
					while(l<auth.length)
					{
						if(author.containsKey(auth[l])==true)
				    	{
				    		count=author.get(auth[l]);
				    		count.add(i);
				    		author.remove(auth[l]);
				    		author.put(auth[l],count);
				    	}
				    	else
				    	{
				    		count.add(i);
				    		author.put(auth[l],count);
				        }
						
						l++;
					}
					l=0;
					s = name.readLine();
					s = name.readLine();
					String[] abst;
					int count3=1;
				 while((s = name.readLine())!= null)
				 {
					 abst=s.split(" ");
						
					    while(z<abst.length)
					    {
					    	if(absoffiles.containsKey(abst[z])==true)
					    	{
					    		count3=absoffiles.get(abst[z]);
					    		count3++;
					    		absoffiles.remove(abst[z]);
					    		absoffiles.put(abst[z],count3);
					    	}
					    	else
					    	{
					    	absoffiles.put(abst[z],count3);
					    	}
					    	z++;
					    }
					    z=0;
				     
				 }
	             
				}//end of while
				
			}//end of try 
			catch (IOException e) {
				e.printStackTrace();
			}// end of catch 
			
				
			
		i++;	
		}//end of while
/////////////////////////////////////////		
		@SuppressWarnings("resource")
		Scanner a= new Scanner (System.in);
		System.out.println("Enter value of K");
		k=a.nextInt();
		System.out.println("Option 0");
		System.out.println("Option 1");
		System.out.println("Option 2");
		System.out.println("Option 3");
		
while(ter==0)
	{
	op=a.nextInt();

		if(op==0)
        {
        	System.exit(0);
        }
        else if(op==1)
        {
        	
        	String title = a.nextLine(); 
        	title = a.nextLine();// for string
        	System.out.println("title entered "+title );
        	option1(title);
        	sortedabs=sort(abs);
        	
        	 for (Entry<String, Integer> entry : sortedabs.entrySet())
             {  
        		 if(m<k)
        		 {
        			 System.out.println("Word : " + entry.getKey() + " ::  Count : "+ entry.getValue());	 
        		 }
                 m++;
             }
        	 m=0;
        }
        else if(op==2)
        {
        	//input author name
        	String au = a.nextLine(); 
        	au = a.nextLine();// for string
        	System.out.println("author entered "+au);
        	ArrayList <Integer> files= author.get(au);
        	
        	option2(files);
        	sortedabs=sort(absauthor);
          	 for (Entry<String, Integer> entry : sortedabs.entrySet())
               {  
          		 if(m<k)
          		 {
          			 System.out.println("Word : " + entry.getKey() + " ::  Count : "+ entry.getValue());	 
          		 }
                   m++;
               }
          	 m=0;
           }
        	
        
        else if(op==3)
        {
        	//print abstract
        	sortedabs=sort(absoffiles);
       	 for (Entry<String, Integer> entry : sortedabs.entrySet())
            {  
       		 if(m<k)
       		 {
       			 System.out.println("Word : " + entry.getKey() + " Count : "+ entry.getValue());	 
       		 }
                m++;
            }
       	 m=0;
        }
        else
        {
        	System.out.println("Wrong choice");
        }
		
	}//end of while
        
	}//end of main



static int option1(String req)
{

Integer val;
if(header.containsKey(req));
val=header.get(req);
if(val>20||val<0)
{
	System.out.println("No such title");
	return 0;
}
String file, temp;
String[] abst;
int j=0;
file="./src/"+"paper"+val+ ".txt";

try {
	@SuppressWarnings("resource")
	BufferedReader n= new BufferedReader(new FileReader(file));
	temp = n.readLine();
	temp = n.readLine();
	temp = n.readLine();
	temp = n.readLine();
	temp = n.readLine();
	int count=1;
	while ((temp = n.readLine())!= null) 
	{
		abst=temp.split(" ");
		
	    while(j<abst.length)
	    {
	    	if(abs.containsKey(abst[j])==true)
	    	{
	    		count=abs.get(abst[j]);
	    		count++;
	    		abs.remove(abst[j]);
	    		abs.put(abst[j],count);
	    	}
	    	else
	    	{
	    	abs.put(abst[j],count);
	    	}
	    	j++;
	    }
	    j=0;
     
	}//end of while

} catch (IOException e) {

	e.printStackTrace();
}
return 0;

}//end of option1
static void option2(ArrayList <Integer> files)
{
	int i=0,j=0;
	
	String file,temp;
	String[] abst;
	while(i<files.size())
	{  
		file="./src/"+"paper"+files.get(i)+ ".txt";

		try {
			@SuppressWarnings("resource")
			BufferedReader n= new BufferedReader(new FileReader(file));
			temp = n.readLine();
			temp = n.readLine();
			temp = n.readLine();
			temp = n.readLine();
			temp = n.readLine();
			int count=1;
			while ((temp = n.readLine())!= null) 
			{
				abst=temp.split(" ");
				
			    while(j<abst.length)
			    {
			    	if(absauthor.containsKey(abst[j])==true)
			    	{
			    		count=absauthor.get(abst[j]);
			    		count++;
			    		absauthor.remove(abst[j]);
			    		absauthor.put(abst[j],count);
			    	}
			    	else
			    	{
			    	absauthor.put(abst[j],count);
			    	}
			    	j++;
			    }
			    j=0;
		     
			}//end of while

		} catch (IOException e) {

			e.printStackTrace();
		}
		i++;
	}
	
	
}
private static Map<String, Integer> sort(Map<String, Integer> unsortMap) {

	// Convert Map to List
	List<Map.Entry<String, Integer>> list = 
		new LinkedList<Map.Entry<String, Integer>>(unsortMap.entrySet());

	// Sort list with comparator, to compare the Map values
	Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
		public int compare(Map.Entry<String, Integer> o1,
                                       Map.Entry<String, Integer> o2) {
			return (o1.getValue()).compareTo(o2.getValue());
		}
	});

	// Convert sorted map back to a Map
	Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
	for (Iterator<Map.Entry<String, Integer>> it = list.iterator(); it.hasNext();) {
		Map.Entry<String, Integer> entry = it.next();
		sortedMap.put(entry.getKey(), entry.getValue());
	}
	return sortedMap;
}
}//end of class
